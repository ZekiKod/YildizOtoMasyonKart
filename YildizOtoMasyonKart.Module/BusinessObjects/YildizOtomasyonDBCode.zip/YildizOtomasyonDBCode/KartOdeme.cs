﻿using System;
using DevExpress.Xpo;
using DevExpress.Xpo.Metadata;
using DevExpress.Data.Filtering;
using System.Collections.Generic;
using System.ComponentModel;
using System.Reflection;
using DevExpress.Persistent.Base;

namespace YildizOtomasyon.Module.BusinessObjects.YildizOtomasyonDB
{
    [DefaultClassOptions]
    public partial class KartOdeme
    {
        private decimal originalYatanTutar;

        public KartOdeme(Session session) : base(session) { }

        public override void AfterConstruction()
        {
            Tarih=DateTime.Now;
            base.AfterConstruction();
        }


        protected override void OnSaving()
        {
            base.OnSaving();

            // Örneğin, KartBilgisi'nin null olup olmadığını kontrol edelim
            if (KartBilgisi != null)
            {
                decimal krtytn = KartBilgisi.KartOdemes?.Where(x=>x.iade==false).Sum(x => x.YatanTutar) ?? 0;
                decimal gcstpl = (KartBilgisi.GirisCikislars?.Where(x => x.iade == false).Sum(x => x.Tutar) ?? 0) + (KartBilgisi.SatilanUrunlers?.Sum(x => x.Fiyat) ?? 0);

                KartBilgisi.KartBakiye = krtytn - gcstpl;
            }
            else
            {
                // KartBilgisi null ise burada uygun bir işlem yapın, örneğin bir log kaydı
                // veya özel bir durum fırlatabilirsiniz.
            }
        }


        //protected override void OnLoaded()
        //{
        //    base.OnLoaded();
        //    originalYatanTutar = YatanTutar;
        //}

        //protected override void OnSaving()
        //{


        //    if (this.Session.IsNewObject(this))
        //    {
        //        // Yeni kayıt ekleniyor
        //        KartBilgisi.KartBakiye = KartBilgisi.KartBakiye + YatanTutar;

        //    }
        //    else
        //    {
        //        // Var olan kayıt güncelleniyor
        //        if (originalYatanTutar != YatanTutar)
        //        {
        //            KartBilgisi.KartBakiye = KartBilgisi.KartBakiye - originalYatanTutar + YatanTutar;
        //        }
        //    }

        //    // // KartBilgisi nesnesini kaydediyoruz

        //}

        //protected override void OnDeleting()
        //{
        //    base.OnDeleting();

        //    // Kayıt siliniyor
        //    KartBilgisi.KartBakiye = KartBilgisi.KartBakiye - YatanTutar;
        //    this.Session.Save(KartBilgisi); // KartBilgisi nesnesini kaydediyoruz
        //}
    }
}
